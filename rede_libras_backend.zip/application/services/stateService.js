var stateRepository = require('../repositories/stateRepository');

exports.dropDownList = (id, done) => {

    stateRepository.dropDownList(id, done);

};