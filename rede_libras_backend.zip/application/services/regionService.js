var regionRepository = require('../repositories/regionRepository');

exports.dropDownList = (done) => {

    regionRepository.dropDownList(done);

};